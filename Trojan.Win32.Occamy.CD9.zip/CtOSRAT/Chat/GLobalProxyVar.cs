﻿namespace Chat
{
    using Microsoft.VisualBasic.CompilerServices;
    using System;

    [StandardModule]
    internal sealed class GLobalProxyVar
    {
        public static int ClientConnect = 0;
        public static int ErrorCOnnect = 0;
    }
}

