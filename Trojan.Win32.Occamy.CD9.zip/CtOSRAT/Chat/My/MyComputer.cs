﻿namespace Chat.My
{
    using Microsoft.VisualBasic.Devices;
    using System.CodeDom.Compiler;
    using System.ComponentModel;

    [EditorBrowsable(EditorBrowsableState.Never), GeneratedCode("MyTemplate", "8.0.0.0")]
    internal class MyComputer : Computer
    {
    }
}

