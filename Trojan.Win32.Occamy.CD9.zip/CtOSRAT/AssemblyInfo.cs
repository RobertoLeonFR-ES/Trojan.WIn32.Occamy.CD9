﻿// Assembly ctOS, Version 1.0.0.0

[assembly: System.Reflection.AssemblyProduct("WindowsDatabase")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.DisableOptimizations | System.Diagnostics.DebuggableAttribute.DebuggingModes.EnableEditAndContinue | System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | System.Diagnostics.DebuggableAttribute.DebuggingModes.Default)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9 Microsoft 2010")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyTitle("WindowsDatabase")]
[assembly: System.Reflection.AssemblyCompany("Microsoft Corporation")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.InteropServices.Guid("134B90AC-FEEC-459B-8DA4-A4B9E4B2079E")]
[assembly: System.Runtime.InteropServices.ComVisible(true)]
[assembly: System.Reflection.AssemblyTrademark("")]

